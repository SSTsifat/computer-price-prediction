import pickle
import pandas as pd
import numpy as np
import json
import os
from typing import Tuple, List, Dict, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class ModelManager:
	"""Manages the machine learning models and their predictions."""
	
	def __init__(self):
		self.features: List[str] = []
		self.random_forest_model = None
		self.regression_model = None
		self._is_loaded = False
	
	def load_models(self) -> None:
		"""Load the machine learning models and feature list."""
		try:
			# Load features
			features_path = Path("Required/features.json")
			if not features_path.exists():
				raise FileNotFoundError(f"Features file not found at {features_path}")
			
			with open(features_path, "r") as f:
				self.features = json.load(f)
			
			# Load Random Forest model
			rf_path = Path("Required/RFModel")
			if not rf_path.exists():
				raise FileNotFoundError(f"Random Forest model not found at {rf_path}")
			
			with open(rf_path, "rb") as f:
				self.random_forest_model = pickle.load(f)
			
			# Load Regression model
			rg_path = Path("Required/RGModel")
			if not rg_path.exists():
				raise FileNotFoundError(f"Regression model not found at {rg_path}")
			
			with open(rg_path, "rb") as f:
				self.regression_model = pickle.load(f)
			
			self._is_loaded = True
			logger.info("All models loaded successfully")
			
		except Exception as e:
			logger.error(f"Error loading models: {str(e)}")
			raise
	
	def _create_feature_vector(
		self,
		inches: float,
		cpu: float,
		ram: float,
		weight: float,
		h_res: float,
		v_res: float,
		ssd: float,
		hdd: float,
		graphics: str,
		os: str,
		is_gaming: int
	) -> pd.DataFrame:
		"""Create a feature vector from the input parameters."""
		if not self._is_loaded:
			raise RuntimeError("Models not loaded. Call load_models() first.")
		
		# Initialize feature vector
		feature_vector = np.zeros(len(self.features))
		
		# Set numerical features
		feature_vector[0] = inches
		feature_vector[1] = cpu
		feature_vector[2] = ram
		feature_vector[3] = weight
		feature_vector[4] = h_res
		feature_vector[5] = v_res
		feature_vector[6] = ssd
		feature_vector[7] = hdd
		
		# Set categorical features
		try:
			gpu_index = self.features.index(graphics)
			feature_vector[gpu_index] = 1
		except ValueError:
			logger.warning(f"Graphics card {graphics} not found in features")
		
		try:
			os_index = self.features.index(os)
			feature_vector[os_index] = 1
		except ValueError:
			logger.warning(f"Operating system {os} not found in features")
		
		# Set gaming flag
		feature_vector[-1] = is_gaming
		
		return pd.DataFrame([feature_vector], columns=self.features)
	
	def predict(
		self,
		inches: float,
		cpu: float,
		ram: float,
		weight: float,
		h_res: float,
		v_res: float,
		ssd: float,
		hdd: float,
		graphics: str,
		os: str,
		is_gaming: int
	) -> Tuple[float, float]:
		"""
		Make predictions using both models.
		
		Returns:
			Tuple[float, float]: (best_prediction, average_prediction)
		"""
		if not self._is_loaded:
			raise RuntimeError("Models not loaded. Call load_models() first.")
		
		try:
			# Create feature vector
			features_df = self._create_feature_vector(
				inches, cpu, ram, weight, h_res, v_res,
				ssd, hdd, graphics, os, is_gaming
			)
			
			# Make predictions
			best_prediction = self.random_forest_model.predict(features_df)[0]
			avg_prediction = self.regression_model.predict(features_df)[0]
			
			return best_prediction, avg_prediction
			
		except Exception as e:
			logger.error(f"Error making predictions: {str(e)}")
			raise

# Create global model manager instance
_model_manager = ModelManager()

def load() -> None:
	"""Load the machine learning models."""
	_model_manager.load_models()

def Predict(
	inches: float,
	cpu: float,
	ram: float,
	weight: float,
	h_res: float,
	v_res: float,
	ssd: float,
	hdd: float,
	graphics: str,
	os: str,
	is_gaming: int
) -> Tuple[float, float]:
	"""
	Make predictions using the loaded models.
	
	Args:
		inches: Screen size in inches
		cpu: CPU performance score
		ram: RAM in GB
		weight: Weight in kg
		h_res: Horizontal resolution
		v_res: Vertical resolution
		ssd: SSD storage in GB
		hdd: HDD storage in GB
		graphics: Graphics card name
		os: Operating system
		is_gaming: Whether it's a gaming laptop (1) or not (0)
	
	Returns:
		Tuple[float, float]: (best_prediction, average_prediction)
	"""
	return _model_manager.predict(
		inches, cpu, ram, weight, h_res, v_res,
		ssd, hdd, graphics, os, is_gaming
	)

if __name__ == "__main__":
	logging.basicConfig(level=logging.INFO)
	load()
 