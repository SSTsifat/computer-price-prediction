# Laptop Price Predictor

This project is a machine learning-based laptop price prediction system that uses Random Forest and Regression models to predict laptop prices based on various specifications.

## Project Structure
```
laptop_price_predictor/
├── App/
│   ├── Server/
│   │   ├── Required/
│   │   │   ├── features.json
│   │   │   ├── RFModel
│   │   │   └── RGModel
│   │   ├── ServerApp.py
│   │   └── util.py
│   └── Client/
│       ├── app.html
│       ├── app.css
│       └── app.js
└── requirements.txt
```

## Setup Instructions

1. Install Python 3.8 or higher
2. Install required packages:
   ```
   pip install -r requirements.txt
   ```
3. Start the server:
   ```
   cd App/Server
   python ServerApp.py
   ```
4. Open `App/Client/app.html` in a web browser

## Features
- Predicts laptop prices based on specifications
- Uses machine learning models (Random Forest and Regression)
- Web-based interface for easy interaction
- Real-time predictions

## API Endpoints
- POST `/api/predict_price`: Predicts laptop price based on specifications

## Input Parameters
- Screen size (inches)
- CPU performance score
- RAM (GB)
- Weight (kg)
- Resolution (e.g., "1920x1080")
- SSD storage (GB)
- HDD storage (GB)
- Graphics card
- Operating system
- Gaming laptop flag
